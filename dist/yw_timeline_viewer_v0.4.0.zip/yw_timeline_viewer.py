"""A timeline viewer application for yWriter projects.

Version 0.4.0
Requires Python 3.6+
Copyright (c) 2025 Peter Triesberger
For further information see https://github.com/peter88213/yw_tlview
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify \
it under the terms of the GNU General Public License as published by \
the Free Software Foundation, either version 3 of the License, or \
(at your option) any later version.

This program is distributed in the hope that it will be useful, \
but WITHOUT ANY WARRANTY; without even the implied warranty of \
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the \
GNU General Public License for more details.
"""
import locale
import os
import sys
from tkinter import messagebox
from tkinter import ttk


from datetime import datetime

from datetime import date
from datetime import datetime
from datetime import timedelta

import gettext

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation('nv_tlview', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message



def from_timestamp(ts):
    return datetime.min + timedelta(seconds=ts)


def get_duration(seconds):
    minutes = seconds // 60
    hours, minutes = divmod(minutes, 60)
    days, hours = divmod(hours, 24)
    return days, hours, minutes


def get_duration_str(days, hours, minutes):
    durationStr = ''
    if days:
        durationStr = f' {days} {_("d")}'
    if hours:
        durationStr = f' {durationStr} {hours} {_("h")}'
    if minutes:
        durationStr = f' {durationStr} {minutes} {_("m")}'
    return durationStr


def get_seconds(days, hours, minutes):
    seconds = 0
    if days:
        seconds = int(days) * 24 * 3600
    if hours:
        seconds += int(hours) * 3600
    if minutes:
        seconds += int(minutes) * 60
    return seconds


def get_specific_date(dayStr, refIso):
    refDate = date.fromisoformat(refIso)
    return date.isoformat(refDate + timedelta(days=int(dayStr)))


def get_timestamp(dt):
    return int((dt - datetime.min).total_seconds() + 0.5)


def get_unspecific_date(dateIso, refIso):
    refDate = date.fromisoformat(refIso)
    return str((date.fromisoformat(dateIso) - refDate).days)

from calendar import day_abbr
from datetime import datetime
from tkinter import ttk

import platform



class GenericKeys:

    OPEN_HELP = ('<F1>', 'F1')
    OPEN_PROJECT = ('<Control-o>', f'{_("Ctrl")}-O')
    QUIT_PROGRAM = ('<Control-q>', f'{_("Ctrl")}-Q')
    RELOAD_PROJECT = ('<Control-r>', f'{_("Ctrl")}-R')
    SAVE_AS = ('<Control-S>', f'{_("Ctrl")}-{_("Shift")}-S')
    SAVE_PROJECT = ('<Control-s>', f'{_("Ctrl")}-S')
    UNDO = ('<Control-z>', f'{_("Ctrl")}-Z')


class GenericMouse:

    ADJUST_CASCADING = '<Control-Shift-MouseWheel>'
    LEFT_CLICK = '<Button-1>'
    MOVE_TIME_SCALE = '<Shift-MouseWheel>'
    RIGHT_CLICK = '<Button-3>'
    RIGHT_MOTION = '<B3-Motion>'
    RIGHT_RELEASE = '<ButtonRelease-3>'
    STRETCH_TIME_SCALE = '<Control-MouseWheel>'


class LinuxMouse(GenericMouse):

    BACK_SCROLL = '<Button-4>'
    FORWARD_SCROLL = '<Button-5>'
    ADJUST_CASCADING_BCK = '<Control-Shift-Button-4>'
    ADJUST_CASCADING_FWD = '<Control-Shift-Button-5>'
    MOVE_TIME_SCALE_BCK = '<Shift-Button-4>'
    MOVE_TIME_SCALE_FWD = '<Shift-Button-5>'
    STRETCH_TIME_SCALE_BCK = '<Control-Button-4>'
    STRETCH_TIME_SCALE_FWD = '<Control-Button-5>'



class MacKeys(GenericKeys):

    QUIT_PROGRAM = ('<Command-q>', 'Cmd-Q')
    UNDO = ('<Command-z>', 'Cmd-Z')



class MacMouse(GenericMouse):

    ADJUST_CASCADING = '<Command-Shift-MouseWheel>'
    RIGHT_CLICK = '<Button-2>'
    RIGHT_MOTION = '<B2-Motion>'
    RIGHT_RELEASE = '<ButtonRelease-2>'
    STRETCH_TIME_SCALE = '<Command-MouseWheel>'



class WindowsKeys(GenericKeys):

    QUIT_PROGRAM = ('<Alt-F4>', 'Alt-F4')



class WindowsMouse(GenericMouse):

    BACK_CLICK = '<Button-4>'
    FORWARD_CLICK = '<Button-5>'


if platform.system() == 'Windows':
    PLATFORM = 'win'
    KEYS = WindowsKeys()
    MOUSE = WindowsMouse()
elif platform.system() in ('Linux', 'FreeBSD'):
    PLATFORM = 'ix'
    KEYS = GenericKeys()
    MOUSE = LinuxMouse()
elif platform.system() == 'Darwin':
    PLATFORM = 'mac'
    KEYS = MacKeys()
    MOUSE = MacMouse()
else:
    PLATFORM = ''
    KEYS = GenericKeys()
    MOUSE = GenericMouse()


MAJOR_HEIGHT = 15
MINOR_HEIGHT = 30
SCALE_SPACING_MIN = 120
MINOR_SPACING_MIN = 40
SCALE_SPACING_MAX = 480

HOUR = 3600
DAY = HOUR * 24
YEAR = DAY * 365
MONTH = DAY * 30

from tkinter import ttk

from _datetime import date
from calendar import day_abbr
from calendar import month_abbr

import tkinter as tk


class TlvScaleCanvas(tk.Canvas):

    def __init__(self, tlvController, master=None, **kw):
        super().__init__(master, cnf={}, **kw)
        self._tlvCtrl = tlvController
        self['background'] = 'gray25'
        self._majorScaleColor = 'white'
        self._minorScaleColor = 'gray60'
        self.majorSpacing = None
        self.minorSpacing = None

    def draw(self, startTimestamp, scale, specificDate, refIso):
        self.delete("all")
        if not specificDate:
            if refIso is None:
                refIso = '0001-01-01'
                showWeekDay = False
            else:
                showWeekDay = True


        resolution = HOUR
        self.majorSpacing = resolution / scale
        units = 0
        while self.majorSpacing < SCALE_SPACING_MIN:
            resolution *= 2
            if units == 0 and resolution >= DAY:
                resolution = DAY
                units = 1
            elif units == 1 and resolution >= MONTH:
                resolution = MONTH
                units = 2
            elif units == 2 and resolution >= YEAR:
                resolution = YEAR
                units = 3
            self.majorSpacing = resolution / scale

        tsOffset = resolution - startTimestamp % resolution
        if tsOffset == resolution:
            tsOffset = 0
        xPos = tsOffset / scale
        timestamp = startTimestamp + tsOffset

        xMax = self.winfo_width()
        while xPos < xMax:
            try:
                dt = from_timestamp(timestamp)
            except OverflowError:
                break

            if specificDate:
                weekDay = day_abbr[dt.weekday()]
                month = month_abbr[dt.month]
                if units == 0:
                    dtStr = f"{weekDay} {self._tlvCtrl.datestr(dt)}"
                if units == 1:
                    dtStr = f"{weekDay} {self._tlvCtrl.datestr(dt)}"
                elif units == 2:
                    dtStr = f"{month} {dt.year}"
                elif units == 3:
                    dtStr = f"{dt.year}"
            else:
                day = get_unspecific_date(date.isoformat(dt), refIso)
                if showWeekDay:
                    weekDay = f'{day_abbr[dt.weekday()]} '
                else:
                    weekDay = ''
                if units == 0:
                    dtStr = f"{weekDay} {_('Day')} {day}"
                if units == 1:
                    dtStr = f"{weekDay} {_('Day')} {day}"
                elif units == 2:
                    dtStr = f"{_('Day')} {day}"
                elif units == 3:
                    dtStr = f"{_('Day')} {day}"

            self.create_line((xPos, 0), (xPos, MAJOR_HEIGHT), width=1, fill=self._majorScaleColor)
            self.create_text((xPos + 5, 2), text=dtStr, fill=self._majorScaleColor, anchor='nw')
            xPos += self.majorSpacing
            timestamp += resolution


        resolution /= 4
        self.minorSpacing = resolution / scale
        while self.minorSpacing < MINOR_SPACING_MIN:
            resolution *= 2
            if units == 0 and resolution >= DAY:
                resolution = DAY
            elif units == 1 and resolution >= YEAR:
                resolution = YEAR
            self.minorSpacing = resolution / scale

        tsOffset = resolution - startTimestamp % resolution
        if tsOffset == resolution:
            tsOffset = 0
        xPos = tsOffset / scale
        timestamp = startTimestamp + tsOffset

        xMax = self.winfo_width()
        while xPos < xMax:
            try:
                dt = from_timestamp(timestamp)
            except OverflowError:
                break

            if specificDate:
                weekDay = day_abbr[dt.weekday()]
                month = month_abbr[dt.month]
                if units == 0:
                    dtStr = f"{dt.hour:02}:{dt.minute:02}"
                elif units == 1:
                    dtStr = f"{weekDay} {dt.day}"
                elif units == 2:
                    dtStr = f"{month}"
                elif units == 3:
                    dtStr = f"{dt.year}"
            else:
                day = get_unspecific_date(date.isoformat(dt), refIso)
                weekDay = day_abbr[dt.weekday()]
                if units == 0:
                    dtStr = f"{dt.hour:02}:{dt.minute:02}"
                elif units == 1:
                    dtStr = day
                elif units == 2:
                    dtStr = day
                elif units == 3:
                    dtStr = day

            self.create_line((xPos, MAJOR_HEIGHT), (xPos, MINOR_HEIGHT), width=1, fill=self._minorScaleColor)
            self.create_text((xPos + 5, MAJOR_HEIGHT + 1), text=dtStr, fill=self._minorScaleColor, anchor='nw')
            xPos += self.minorSpacing
            timestamp += resolution

    def get_window_width(self):
        self.update()
        return self.winfo_width()



class TlvSectionCanvas(tk.Canvas):
    EVENT_DIST_Y = 35
    LABEL_DIST_X = 10
    MARK_HALF = 5
    isLocked = False

    def __init__(self, tlvController, master=None, **kw):
        super().__init__(master, cnf={}, **kw)
        self._tlvCtrl = tlvController
        self['background'] = 'black'
        self.eventMarkColor = 'red'
        self.eventTitleColor = 'white'
        self.eventDateColor = 'gray60'
        self.indicatorColor = 'lightblue'
        self.srtSections = []
        self.yMax = 0

        self._xPos = None
        self._xStart = None
        self._active_object = None
        self._indicator = None
        self._indicatorText = None

        self.bind_all('<Escape>', self._on_escape)

    def delete_indicator(self):
        self.delete(self._indicator)
        self.delete(self._indicatorText)

    def draw(self, startTimestamp, scale, srtSections, minDist):
        self.delete("all")
        self.yMax = (len(srtSections) + 2) * self.EVENT_DIST_Y
        yStart = self.EVENT_DIST_Y
        xEnd = 0
        yPos = yStart
        labelEnd = 0
        for section in srtSections:
            timestamp, durationSeconds, title, timeStr, eventId = section
            xStart = (timestamp - startTimestamp) / scale

            if xStart > labelEnd + minDist:
                yPos = yStart
                labelEnd = 0

            xEnd = (timestamp - startTimestamp + durationSeconds) / scale
            sectionMark = self.create_polygon(
                (xStart, yPos - self.MARK_HALF),
                (xStart - self.MARK_HALF, yPos),
                (xStart, yPos + self.MARK_HALF),
                (xEnd, yPos + self.MARK_HALF),
                (xEnd + self.MARK_HALF, yPos),
                (xEnd, yPos - self.MARK_HALF),
                fill=self.eventMarkColor,
                tags=eventId
                )
            self.tag_bind(sectionMark, '<Double-Button-1>', self._on_double_click)
            self.tag_bind(sectionMark, '<Shift-Button-1>', self._on_shift_click)
            self.tag_bind(sectionMark, '<Control-Shift-Button-1>', self._on_ctrl_shift_click)

            xLabel = xEnd + self.LABEL_DIST_X
            titleLabel = self.create_text((xLabel, yPos), text=title, fill=self.eventTitleColor, anchor='w')
            titleBounds = self.bbox(titleLabel)
            if titleBounds is not None:
                self.create_text(xLabel, titleBounds[3], text=timeStr, fill=self.eventDateColor, anchor='nw')
                __, __, x2, __ = self.bbox('all')
                labelEnd = x2
            yPos += self.EVENT_DIST_Y
        totalBounds = self.bbox('all')
        if totalBounds is not None:
            self.configure(scrollregion=(0, 0, 0, totalBounds[3]))

    def draw_indicator(self, xPos, text=''):
        self.delete_indicator()
        self._indicator = self.create_line(
            (xPos, 0),
            (xPos, self.yMax),
            width=1,
            dash=(2, 2),
            fill=self.indicatorColor,
            )
        self._indicatorText = self.create_text(
            (xPos + 5, 5),
            text=text,
            anchor='nw',
            fill=self.indicatorColor
            )

    def get_section_id(self, event):
        return event.widget.itemcget('current', 'tag').split(' ')[0]

    def _move_indicator(self, deltaX):
        self.move(self._indicator, deltaX, 0)
        self.move(self._indicatorText, deltaX, 0)

    def _on_ctrl_shift_click(self, event):
        if self.isLocked:
            return

        self._active_object = self.get_section_id(event)
        self.tag_bind(self._active_object, '<ButtonRelease-1>', self._on_ctrl_shift_release)
        self.tag_bind(self._active_object, '<B1-Motion>', self._on_drag)
        __, __, x2, __ = self.bbox(self._active_object)
        self._xStart = x2 - self.MARK_HALF
        self._xPos = event.x
        self.draw_indicator(
            self._xStart,
            text=f'{_("Shift end")}: {self._tlvCtrl.get_section_title(self._active_object)}'
            )
        self._xStart = event.x

    def _on_ctrl_shift_release(self, event):
        try:
            self.tag_unbind(self._active_object, '<ButtonRelease-1>')
            self.tag_unbind(self._active_object, '<B1-Motion>')
        except:
            return

        deltaX = event.x - self._xStart
        self._tlvCtrl.shift_event_end(self._active_object, deltaX)
        self._active_object = None

    def _on_double_click(self, event):
        self.event_generate('<<double-click>>', when='tail')

    def _on_drag(self, event):
        deltaX = event.x - self._xPos
        self._xPos = event.x
        self._move_indicator(deltaX)

    def _on_escape(self, event):
        self.unbind_all('<ButtonRelease-1>')
        self.unbind_all('<B1-Motion>')
        self.delete_indicator()
        self._active_object = None

    def _on_shift_click(self, event):
        if self.isLocked:
            return

        self._active_object = self.get_section_id(event)
        self.tag_bind(self._active_object, '<ButtonRelease-1>', self._on_shift_release)
        self.tag_bind(self._active_object, '<B1-Motion>', self._on_drag)
        x1, __, __, __ = self.bbox(self._active_object)
        self._xStart = x1 + self.MARK_HALF
        self._xPos = event.x
        self.draw_indicator(
            self._xStart,
            text=f'{_("Shift start")}: {self._tlvCtrl.get_section_title(self._active_object)}'
            )
        self._xStart = event.x

    def _on_shift_release(self, event):
        try:
            self.tag_unbind(self._active_object, '<ButtonRelease-1>')
            self.tag_unbind(self._active_object, '<B1-Motion>')
        except:
            return

        deltaX = event.x - self._xStart
        self._tlvCtrl.shift_event(self._active_object, deltaX)
        self._active_object = None



class TlvScrollFrame(ttk.Frame):
    SCALE_HEIGHT = MINOR_HEIGHT

    def __init__(self, parent, tlvController, *args, **kw):

        ttk.Frame.__init__(self, parent, *args, **kw)

        scrollY = ttk.Scrollbar(self, orient='vertical', command=self.yview)
        scrollY.pack(fill='y', side='right', expand=False)

        self._scaleCanvas = TlvScaleCanvas(
            tlvController,
            self,
            height=self.SCALE_HEIGHT,
            borderwidth=0,
            highlightthickness=0
            )
        self._scaleCanvas.pack(
            anchor='n',
            fill='x',
            )

        self._sectionCanvas = TlvSectionCanvas(
            tlvController,
            self,
            borderwidth=0,
            highlightthickness=0
            )
        self._sectionCanvas.configure(yscrollcommand=scrollY.set)
        self._sectionCanvas.pack(
            anchor='n',
            fill='both',
            expand=True
            )
        self._sectionCanvas.xview_moveto(0)
        self._sectionCanvas.yview_moveto(0)

        if PLATFORM == 'ix':
            self._sectionCanvas.bind(MOUSE.BACK_SCROLL, self.on_mouse_wheel)
            self._sectionCanvas.bind(MOUSE.FORWARD_SCROLL, self.on_mouse_wheel)
        else:
            self._sectionCanvas.bind('<MouseWheel>', self.on_mouse_wheel)

        self._yscrollincrement = self._sectionCanvas['yscrollincrement']

    def bind_section_canvas_event(self, event, command):
        self._sectionCanvas.bind(event, command)

    def destroy(self):
        if PLATFORM == 'ix':
            self._sectionCanvas.unbind_all(MOUSE.BACK_SCROLL)
            self._sectionCanvas.unbind_all(MOUSE.FORWARD_SCROLL)
            self._sectionCanvas.unbind_all(MOUSE.STRETCH_TIME_SCALE_BCK)
            self._sectionCanvas.unbind_all(MOUSE.STRETCH_TIME_SCALE_FWD)
            self._sectionCanvas.unbind_all(MOUSE.MOVE_TIME_SCALE_BCK)
            self._sectionCanvas.unbind_all(MOUSE.MOVE_TIME_SCALE_FWD)
            self._sectionCanvas.unbind_all(MOUSE.ADJUST_CASCADING_BCK)
            self._sectionCanvas.unbind_all(MOUSE.ADJUST_CASCADING_FWD)
        else:
            self._sectionCanvas.unbind_all('<MouseWheel>')
            self._sectionCanvas.unbind_all(MOUSE.STRETCH_TIME_SCALE)
            self._sectionCanvas.unbind_all(MOUSE.MOVE_TIME_SCALE)
            self._sectionCanvas.unbind_all(MOUSE.ADJUST_CASCADING)
        super().destroy()

    def draw_indicator(self, xPos, text=''):
        self._sectionCanvas.draw_indicator(xPos, text)

    def draw_timeline(self, startTimestamp, scale, srtSections, minDist, specificDate, referenceDate):
        self._scaleCanvas.draw(
            startTimestamp,
            scale,
            specificDate,
            referenceDate
            )
        self._sectionCanvas.draw(
            startTimestamp,
            scale,
            srtSections,
            minDist,
            )

    def get_canvas(self):
        return self._sectionCanvas

    def get_scale_mark_spacing(self):
        return self._scaleCanvas.majorSpacing

    def get_window_width(self):
        return self._scaleCanvas.get_window_width()

    def on_mouse_wheel(self, event):
        if PLATFORM == 'win':
            self.yview_scroll(int(-1 * (event.delta / 120)), 'units')
        elif PLATFORM == 'mac':
            self.yview_scroll(int(-1 * event.delta), 'units')
        else:
            if event.num == 4:
                self.yview_scroll(-1, 'units')
            elif event.num == 5:
                self.yview_scroll(1, 'units')

    def set_drag_scrolling(self):
        self._sectionCanvas.configure(yscrollincrement=1)

    def set_normal_scrolling(self):
        self._sectionCanvas.configure(yscrollincrement=self._yscrollincrement)

    def xview(self, *args):
        self._sectionCanvas.xview(*args)

    def yview(self, *args):
        self._sectionCanvas.yview(*args)

    def yview_scroll(self, *args):
        if self._sectionCanvas.yview() == (0.0, 1.0):
            return

        self._sectionCanvas.yview_scroll(*args)



class TlvMainFrame(ttk.Frame):

    MIN_TIMESTAMP = get_timestamp(datetime.min)
    MAX_TIMESTAMP = get_timestamp(datetime.max)

    DISTANCE_MIN = -100
    DISTANCE_MAX = 200
    PAD_X = 100

    SCALE_MIN = 10
    SCALE_MAX = YEAR * 5

    def __init__(self, model, master, tlvController, settings):
        ttk.Frame.__init__(self, master)

        self._dataModel = model
        self.master = master

        self._tlvCtrl = tlvController
        self.pack(fill='both', expand=True)

        self._statusText = ''
        self.isOpen = True

        self._scale = self.SCALE_MIN
        self._startTimestamp = None
        self._minDist = 0
        self._specificDate = None
        self.firstTimestamp = None
        self.lastTimestamp = None
        self.srtSections = None

        self._xPos = None
        self._yPos = None

        self.tlFrame = TlvScrollFrame(self, self._tlvCtrl)
        self.tlFrame.pack(side='top', fill='both', expand=True)

        self.settings = settings

        self._bind_events()
        self.sort_sections()

    @property
    def startTimestamp(self):
        return self._startTimestamp

    @startTimestamp.setter
    def startTimestamp(self, newVal):
        if newVal < self.MIN_TIMESTAMP:
            self._startTimestamp = self.MIN_TIMESTAMP
        elif newVal > self.MAX_TIMESTAMP:
            self._startTimestamp = self.MAX_TIMESTAMP
        else:
            self._startTimestamp = newVal
        self.draw_timeline()

    @property
    def scale(self):
        return self._scale

    @scale.setter
    def scale(self, newVal):
        if newVal < self.SCALE_MIN:
            self._scale = self.SCALE_MIN
        elif newVal > self.SCALE_MAX:
            self._scale = self.SCALE_MAX
        else:
            self._scale = newVal
        self.draw_timeline()

    @property
    def minDist(self):
        return self._minDist

    @minDist.setter
    def minDist(self, newVal):
        if newVal < self.DISTANCE_MIN:
            self._minDist = self.DISTANCE_MIN
        elif newVal > self.DISTANCE_MAX:
            self._minDist = self.DISTANCE_MAX
        else:
            self._minDist = newVal
        self.draw_timeline()

    def draw_timeline(self, event=None):
        if self._calculating:
            return

        self._calculating = True
        if self.startTimestamp is None:
            self.startTimestamp = self.firstTimestamp
        self.tlFrame.draw_timeline(
            self.startTimestamp,
            self.scale,
            self.srtSections,
            self.minDist,
            self._specificDate,
            self._dataModel.referenceDate
            )
        self._calculating = False

    def fit_window(self):
        self.sort_sections()
        width = self.tlFrame.get_window_width() - 2 * self.PAD_X
        self.scale = (self.lastTimestamp - self.firstTimestamp) / width
        self._set_first_event()

    def get_canvas(self):
        return self.tlFrame.get_canvas()

    def go_to_first(self):
        xPos = self._set_first_event()
        self.tlFrame.draw_indicator(xPos)

    def go_to_last(self):
        xPos = self._set_last_event()
        self.tlFrame.draw_indicator(xPos)

    def go_to(self, scId):
        if scId is None:
            return

        sectionTimestamp = self._tlvCtrl.get_section_timestamp(scId)
        if sectionTimestamp is None:
            return

        xPos = self.tlFrame.get_window_width() / 2
        self.startTimestamp = sectionTimestamp - xPos * self.scale
        self.tlFrame.draw_indicator(
            xPos,
            text=self._tlvCtrl.get_section_title(scId)
            )

    def stretch_time_scale(self, event):
        deltaScale = 1.1
        if event.num == 5 or event.delta == -120:
            self.scale *= deltaScale
        if event.num == 4 or event.delta == 120:
            self.scale /= deltaScale
        return 'break'

    def adjust_cascading(self, event):
        deltaDist = 10
        if event.num == 5 or event.delta == -120:
            self.minDist += deltaDist
        if event.num == 4 or event.delta == 120:
            self.minDist -= deltaDist
        return 'break'

    def increase_scale(self):
        self.scale /= 2

    def lock(self):
        TlvSectionCanvas.isLocked = True

    def move_time_scale(self, event):
        deltaOffset = self.scale / self.SCALE_MIN * self.tlFrame.get_scale_mark_spacing()
        if event.num == 5 or event.delta == -120:
            self.startTimestamp += deltaOffset
        if event.num == 4 or event.delta == 120:
            self.startTimestamp -= deltaOffset
        return 'break'

    def on_quit(self):
        self.tlFrame.destroy()
        self.destroy()

    def page_back(self):
        deltaX = self.tlFrame.get_window_width() * 0.9 * self.scale
        self.startTimestamp -= deltaX

    def page_forward(self):
        deltaX = self.tlFrame.get_window_width() * 0.9 * self.scale
        self.startTimestamp += deltaX

    def reduce_scale(self):
        self.scale *= 2

    def reset_casc(self):
        self.minDist = 0

    def scroll_back(self):
        deltaX = self.tlFrame.get_window_width() * 0.2 * self.scale
        self.startTimestamp -= deltaX

    def scroll_forward(self):
        deltaX = self.tlFrame.get_window_width() * 0.2 * self.scale
        self.startTimestamp += deltaX

    def set_casc_relaxed(self):
        self.minDist = self.DISTANCE_MAX

    def set_casc_tight(self):
        self.minDist = self.DISTANCE_MIN

    def set_day_scale(self):
        self.scale = (DAY * 2) / (SCALE_SPACING_MAX - SCALE_SPACING_MIN)

    def set_hour_scale(self):
        self.scale = (HOUR * 2) / (SCALE_SPACING_MAX - SCALE_SPACING_MIN)

    def set_year_scale(self):
        self.scale = (YEAR * 2) / (SCALE_SPACING_MAX - SCALE_SPACING_MIN)

    def sort_sections(self):
        srtSections = []
        self._specificDate = False
        for scId in self._dataModel.sections:
            section = self._dataModel.sections[scId]
            if section.scType != 0:
                continue

            try:
                durationStr = get_duration_str(section.lastsDays, section.lastsHours, section.lastsMinutes)
                refIso = self._dataModel.referenceDate
                if section.time is None:
                    if not self.settings.get('substitute_missing_time', False):
                        continue

                    scTime = '00:00'
                else:
                    scTime = section.time

                if section.date is not None:
                    self._specificDate = True
                    scDate = section.date
                    dt = datetime.fromisoformat(f'{scDate} {scTime}')
                    weekDay = day_abbr[dt.weekday()]
                    timeStr = f"{weekDay} {self._tlvCtrl.datestr(dt)} {dt.hour:02}:{dt.minute:02}{durationStr}"
                elif section.day is not None:
                    if refIso is None:
                        refIso = '0001-01-01'
                        showWeekDay = False
                    else:
                        showWeekDay = True
                    scDate = get_specific_date(section.day, refIso)
                    dt = datetime.fromisoformat(f'{scDate} {scTime}')
                    if showWeekDay:
                        weekDay = f'{day_abbr[dt.weekday()]} '
                    else:
                        weekDay = ''
                    timeStr = f"{weekDay}{_('Day')} {section.day} {dt.hour:02}:{dt.minute:02}{durationStr}"
                else:
                    continue

                srtSections.append(
                        (
                        get_timestamp(dt),
                        get_seconds(section.lastsDays, section.lastsHours, section.lastsMinutes),
                        section.title,
                        timeStr,
                        scId
                        )
                    )
            except:
                pass
        self.srtSections = sorted(srtSections)
        if len(self.srtSections) > 1:
            self.firstTimestamp = self.srtSections[0][0]
            self.lastTimestamp = self.srtSections[-1][0] + self.srtSections[-1][1]
        else:
            self.firstTimestamp = self.MIN_TIMESTAMP
            self.lastTimestamp = self.MAX_TIMESTAMP

    def unlock(self):
        TlvSectionCanvas.isLocked = False

    def _bind_events(self):
        self._calculating = False
        self.bind('<Configure>', self.draw_timeline)

        if PLATFORM == 'win':
            event_callbacks = {
                MOUSE.BACK_CLICK: self.page_back,
                MOUSE.FORWARD_CLICK: self.page_forward,
            }
        else:
            self.bind(KEYS.QUIT_PROGRAM[0], self._tlvCtrl.on_quit)
        if PLATFORM == 'ix':
            event_callbacks = {
                MOUSE.STRETCH_TIME_SCALE_BCK: self.stretch_time_scale,
                MOUSE.STRETCH_TIME_SCALE_FWD: self.stretch_time_scale,
                MOUSE.MOVE_TIME_SCALE_BCK: self.move_time_scale,
                MOUSE.MOVE_TIME_SCALE_FWD: self.move_time_scale,
                MOUSE.ADJUST_CASCADING_BCK: self.adjust_cascading,
                MOUSE.ADJUST_CASCADING_FWD: self.adjust_cascading,
            }
        else:
            event_callbacks = {
                MOUSE.STRETCH_TIME_SCALE: self.stretch_time_scale,
                MOUSE.MOVE_TIME_SCALE: self.move_time_scale,
                MOUSE.ADJUST_CASCADING: self.adjust_cascading,
            }
        event_callbacks.update({
                MOUSE.RIGHT_CLICK: self._on_right_click,
            })
        for sequence, callback in event_callbacks.items():
            self.tlFrame.bind_section_canvas_event(sequence, callback)

    def _on_drag(self, event):
        deltaX = self._xPos - event.x
        self._xPos = event.x
        deltaSeconds = deltaX * self.scale
        self.startTimestamp += deltaSeconds

        deltaY = self._yPos - event.y
        self._yPos = event.y
        self.tlFrame.yview_scroll(int(deltaY), 'units')

    def _on_right_click(self, event):
        self._xPos = event.x
        self._yPos = event.y
        self.tlFrame.bind_section_canvas_event(MOUSE.RIGHT_RELEASE, self._on_right_release)
        self.tlFrame.config(cursor='fleur')
        self.tlFrame.bind_section_canvas_event(MOUSE.RIGHT_MOTION, self._on_drag)
        self.tlFrame.set_drag_scrolling()

    def _on_right_release(self, event):
        self.tlFrame.unbind_all(MOUSE.RIGHT_RELEASE)
        self.tlFrame.config(cursor='arrow')
        self.tlFrame.unbind_all(MOUSE.RIGHT_MOTION)
        self.tlFrame.set_normal_scrolling()

    def _set_first_event(self):
        xPos = self.PAD_X
        self.startTimestamp = self.firstTimestamp - xPos * self.scale
        if self.startTimestamp < self.MIN_TIMESTAMP:
            self.startTimestamp = self.MIN_TIMESTAMP
        return xPos

    def _set_last_event(self):
        xPos = self.tlFrame.get_window_width() - self.PAD_X
        self.startTimestamp = self.lastTimestamp - xPos * self.scale
        return xPos



class TlvPublicApi:

    def canUndo(self):
        if self.controlBuffer:
            return True
        else:
            return False

    def fit_window(self, event=None):
        self.view.fit_window()

    def go_to(self, scId):
        self.view.go_to(scId)

    def go_to_first(self, event=None):
        self.view.go_to_first()

    def go_to_last(self, event=None):
        self.view.go_to_last()

    def increase_scale(self, event=None):
        self.view.increase_scale()

    def lock(self, event=None):
        self.view.lock()

    def refresh(self, event=None):
        self.view.sort_sections()
        self.view.draw_timeline()

    def reset_casc(self, event=None):
        self.view.reset_casc()

    def scroll_back(self, event=None):
        self.view.scroll_back()

    def scroll_forward(self, event=None):
        self.view.scroll_forward()

    def set_casc_relaxed(self, event=None):
        self.view.set_casc_relaxed()

    def set_casc_tight(self, event=None):
        self.view.set_casc_tight

    def set_day_scale(self, event=None):
        self.view.set_day_scale()

    def set_hour_scale(self, event=None):
        self.view.set_hour_scale()

    def set_year_scale(self, event=None):
        self.view.set_year_scale()

    def undo(self, event=None):
        self.pop_event()

    def unlock(self, event=None):
        self.view.unlock()

    def page_back(self, event=None):
        self.view.page_back()

    def page_forward(self, event=None):
        self.view.page_forward()

    def reduce_scale(self, event=None):
        self.view.reduce_scale()



class TlvController(TlvPublicApi):

    def __init__(self, model, window, settings, onDoubleClick=None):
        self._dataModel = model
        self.settings = settings

        self.view = TlvMainFrame(
            self._dataModel,
            window,
            self,
            settings,
            )
        self.isOpen = True
        self.firstTimestamp = None
        self.lastTimestamp = None

        self.controlBuffer = []

        self.on_double_click = onDoubleClick
        self.view.get_canvas().bind('<<double-click>>', self._on_double_click)

    def datestr(self, dt):
        if self.settings.get('localize_date', True):
            return dt.strftime("%x")
        else:
            return dt.isoformat().split('T')[0]

    def get_minutes(self, pixels):
        return pixels * self.view.scale // 60

    def get_section_timestamp(self, scId):
        section = self._dataModel.sections[scId]
        if section.scType != 0:
            return

        try:
            refIso = self._dataModel.referenceDate
            if section.time is None:
                if not self.settings.get('substitute_missing_time', False):
                    return

                scTime = '00:00'
            else:
                scTime = section.time

            if section.date is not None:
                scDate = section.date
            elif section.day is not None:
                if refIso is None:
                    refIso = '0001-01-01'
                scDate = get_specific_date(section.day, refIso)
            else:
                return

            return get_timestamp(datetime.fromisoformat(f'{scDate} {scTime}'))

        except:
            return

    def get_section_id(self, event):
        return self.view.get_canvas().get_section_id(event)

    def get_section_title(self, scId):
        return self._dataModel.sections[scId].title

    def on_quit(self):
        if not self.isOpen:
            return

        self.view.on_quit()
        self.isOpen = False

    def shift_event(self, scId, pixels):
        self.push_event(scId)

        deltaSeconds = int(pixels * self.view.scale)
        section = self._dataModel.sections[scId]
        refIso = self._dataModel.referenceDate
        if section.time is None:
            scTime = '00:00'
        else:
            scTime = section.time
        if section.date is not None:
            scDate = section.date
        elif section.day is not None:
            scDate = get_specific_date(section.day, refIso)
        else:
            scDate = refIso

        timestamp = get_timestamp(datetime.fromisoformat(f'{scDate} {scTime}')) + deltaSeconds
        dt = from_timestamp(timestamp)
        dateStr, timeStr = datetime.isoformat(dt).split('T')
        section.time = timeStr
        if section.date is not None:
            section.date = dateStr
        else:
            dayStr = get_unspecific_date(dateStr, refIso)
            section.day = dayStr

    def shift_event_end(self, scId, pixels):
        self.push_event(scId)

        deltaSeconds = int(pixels * self.view.scale)
        seconds = get_seconds(
            self._dataModel.sections[scId].lastsDays,
            self._dataModel.sections[scId].lastsHours,
            self._dataModel.sections[scId].lastsMinutes
            )
        seconds += deltaSeconds
        if seconds < 0:
            seconds = 0

        days, hours, minutes = get_duration(seconds)
        if days:
            self._dataModel.sections[scId].lastsDays = str(days)
        else:
            self._dataModel.sections[scId].lastsDays = None
        if hours:
            self._dataModel.sections[scId].lastsHours = str(hours)
        else:
            self._dataModel.sections[scId].lastsHours = None
        if minutes:
            self._dataModel.sections[scId].lastsMinutes = str(minutes)
        else:
            self._dataModel.sections[scId].lastsMinutes = None

    def push_event(self, scId):
        section = self._dataModel.sections[scId]
        eventData = (
            scId,
            section.date,
            section.time,
            section.day,
            section.lastsDays,
            section.lastsHours,
            section.lastsMinutes
        )
        self.controlBuffer.append(eventData)
        root = self.view.winfo_toplevel()
        root.event_generate('<<enable_undo>>')

    def pop_event(self, event=None):
        if not self.controlBuffer:
            return

        if TlvSectionCanvas.isLocked:
            return

        eventData = self.controlBuffer.pop()
        scId, sectionDate, sectionTime, sectionDay, sectionLastsDays, sectionLastsHours, sectionLastsMinutes = eventData
        section = self._dataModel.sections[scId]
        section.date = sectionDate
        section.time = sectionTime
        section.day = sectionDay
        section.lastsDays = sectionLastsDays
        section.lastsHours = sectionLastsHours
        section.lastsMinutes = sectionLastsMinutes
        if not self.controlBuffer:
            root = self.view.winfo_toplevel()
            root.event_generate('<<disable_undo>>')

    def _on_double_click(self, event):
        scId = self.get_section_id(event)
        if self.on_double_click is not None:
            self.on_double_click(scId)

from datetime import datetime
import re



def new_id(elements, prefix=''):
    i = 1
    while f'{prefix}{i}' in elements:
        i += 1
    return f'{prefix}{i}'

SC_PREFIX = 'sc'

from abc import ABC
from abc import abstractmethod


class TlvFile(ABC):

    EXTENSION = None

    def __init__(self, model, filePath=None):
        self._mdl = model
        self.filePath = filePath

    @abstractmethod
    def read(self):
        pass

    @abstractmethod
    def write(self):
        pass

from datetime import date
from datetime import time


class TlvSection:

    def __init__(self,
            on_element_change=None,
            title=None,
            desc=None,
            scType=0,
            scDate=None,
            scTime=None,
            day=None,
            lastsMinutes=None,
            lastsHours=None,
            lastsDays=None,
            ):
        if on_element_change is None:
            self.on_element_change = self.do_nothing
        else:
            self.on_element_change = on_element_change
        self._title = title
        self._desc = desc
        self._scType = scType
        try:
            newDate = date.fromisoformat(scDate)
            self._weekDay = newDate.weekday()
            self._localeDate = newDate.strftime('%x')
            self._date = scDate
        except:
            self._weekDay = None
            self._localeDate = None
            self._date = None
        self._time = scTime
        self._day = day
        self._lastsMinutes = lastsMinutes
        self._lastsHours = lastsHours
        self._lastsDays = lastsDays

    @property
    def scType(self):
        return self._scType

    @scType.setter
    def scType(self, newVal):
        if newVal is not None:
            assert type(newVal) == int
        if self._scType != newVal:
            self._scType = newVal
            self.on_element_change()

    @property
    def title(self):
        return self._title

    @title.setter
    def title(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._title != newVal:
            self._title = newVal
            self.on_element_change()

    @property
    def desc(self):
        return self._desc

    @desc.setter
    def desc(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._desc != newVal:
            self._desc = newVal
            self.on_element_change()

    @property
    def date(self):
        return self._date

    @date.setter
    def date(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._date != newVal:
            if not newVal:
                self._date = None
                self._weekDay = None
                self._localeDate = None
                self.on_element_change()
                return

            try:
                newDate = date.fromisoformat(newVal)
                self._weekDay = newDate.weekday()
            except:
                return

            try:
                self._localeDate = newDate.strftime('%x')
            except:
                self._localeDate = newVal
            self._date = newVal
            self.on_element_change()

    @property
    def weekDay(self):
        return self._weekDay

    @property
    def localeDate(self):
        return self._localeDate

    @property
    def time(self):
        return self._time

    @time.setter
    def time(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._time != newVal:
            self._time = newVal
            self.on_element_change()

    @property
    def day(self):
        return self._day

    @day.setter
    def day(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._day != newVal:
            self._day = newVal
            self.on_element_change()

    @property
    def lastsMinutes(self):
        return self._lastsMinutes

    @lastsMinutes.setter
    def lastsMinutes(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._lastsMinutes != newVal:
            self._lastsMinutes = newVal
            self.on_element_change()

    @property
    def lastsHours(self):
        return self._lastsHours

    @lastsHours.setter
    def lastsHours(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._lastsHours != newVal:
            self._lastsHours = newVal
            self.on_element_change()

    @property
    def lastsDays(self):
        return self._lastsDays

    @lastsDays.setter
    def lastsDays(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._lastsDays != newVal:
            self._lastsDays = newVal
            self.on_element_change()

    def do_nothing(self):
        pass

import xml.etree.ElementTree as ET


class Yw7File(TlvFile):

    DESCRIPTION = 'yWriter 7 project'
    EXTENSION = '.yw7'

    def read(self):

        def strip_illegal_characters(text):
            return re.sub('[\x00-\x08|\x0b-\x0c|\x0e-\x1f]', '', text)

        try:
            try:
                with open(self.filePath, 'r', encoding='utf-8') as f:
                    xmlText = f.read()
            except:
                with open(self.filePath, 'r', encoding='utf-16') as f:
                    xmlText = f.read()
        except:
            self.tree = ET.parse(self.filePath)

        xmlText = strip_illegal_characters(xmlText)
        root = ET.fromstring(xmlText)
        del xmlText

        self._mdl.sections = {}

        for xmlScene in root.find('SCENES'):
            scId = new_id(self._mdl.sections, SC_PREFIX)
            self._mdl.sections[scId] = TlvSection()

            if xmlScene.find('Title') is not None:
                self._mdl.sections[scId].title = xmlScene.find('Title').text

            if xmlScene.find('Desc') is not None:
                self._mdl.sections[scId].desc = xmlScene.find('Desc').text

            if xmlScene.find('SpecificDateTime') is not None:
                dateTimeStr = xmlScene.find('SpecificDateTime').text
                dateTime = datetime.fromisoformat(dateTimeStr)
                startDateTime = dateTime.isoformat().split('T')
                self._mdl.sections[scId].date = startDateTime[0]
                self._mdl.sections[scId].time = startDateTime[1]

            else:
                if xmlScene.find('Day') is not None:
                    day = xmlScene.find('Day').text

                    try:
                        int(day)
                    except ValueError:
                        day = ''
                    self._mdl.sections[scId].day = day

                hasUnspecificTime = False
                if xmlScene.find('Hour') is not None:
                    hour = xmlScene.find('Hour').text.zfill(2)
                    hasUnspecificTime = True
                else:
                    hour = '00'
                if xmlScene.find('Minute') is not None:
                    minute = xmlScene.find('Minute').text.zfill(2)
                    hasUnspecificTime = True
                else:
                    minute = '00'
                if hasUnspecificTime:
                    self._mdl.sections[scId].time = f'{hour}:{minute}:00'

            if xmlScene.find('LastsDays') is not None:
                self._mdl.sections[scId].lastsDays = xmlScene.find('LastsDays').text

            if xmlScene.find('LastsHours') is not None:
                self._mdl.sections[scId].lastsHours = xmlScene.find('LastsHours').text

            if xmlScene.find('LastsMinutes') is not None:
                self._mdl.sections[scId].lastsMinutes = xmlScene.find('LastsMinutes').text

            self._mdl.sections[scId].on_element_change = self._mdl.on_element_change

    def write(self):
        pass


class TlvDataModel:

    def __init__(self, dataFileClass):
        self.sections = {}
        self._referenceDate = None

        self._observers = []
        self._isModified = False

        self.dataFile = dataFileClass(self)

    @property
    def isModified(self):
        return self._isModified

    @isModified.setter
    def isModified(self, setFlag):
        self._isModified = setFlag
        self.notify_observers()

    @property
    def referenceDate(self):
        return self._referenceDate

    @referenceDate.setter
    def referenceDate(self, newVal):
        if self._referenceDate != newVal:
            self._referenceDate = newVal
            self.on_element_change()

    def add_observer(self, client):
        if not client in self._observers:
            self._observers.append(client)

    def clear(self):
        for scId in list(self.sections):
            del(self.sections[scId])
        self.referenceDate = None
        self.isModified = False

    def delete_observer(self, client):
        if client in self._observers:
            self._observers.remove(client)

    def notify_observers(self):
        for client in self._observers:
            client.refresh()

    def on_element_change(self):
        self.isModified = True

    def read_data(self, filePath):
        self.dataFile.filePath = filePath
        self.dataFile.read()
        self.isModified = False

    def write_data(self, filePath):
        self.dataFile.filePath = filePath
        self.dataFile.write()
        self.isModified = False

from configparser import ConfigParser


class Configuration:

    def __init__(self, settings={}, options={}):
        self.settings = None
        self.options = None
        self._sLabel = 'SETTINGS'
        self._oLabel = 'OPTIONS'
        self.set(settings, options)

    def read(self, iniFile):
        config = ConfigParser()
        config.read(iniFile, encoding='utf-8')
        if config.has_section(self._sLabel):
            section = config[self._sLabel]
            for setting in self.settings:
                fallback = self.settings[setting]
                self.settings[setting] = section.get(setting, fallback)
        if config.has_section(self._oLabel):
            section = config[self._oLabel]
            for option in self.options:
                fallback = self.options[option]
                self.options[option] = section.getboolean(option, fallback)

    def set(self, settings=None, options=None):
        if settings is not None:
            self.settings = settings.copy()
        if options is not None:
            self.options = options.copy()

    def write(self, iniFile):
        config = ConfigParser()
        if self.settings:
            config.add_section(self._sLabel)
            for settingId in self.settings:
                config.set(self._sLabel, settingId, str(self.settings[settingId]))
        if self.options:
            config.add_section(self._oLabel)
            for settingId in self.options:
                if self.options[settingId]:
                    config.set(self._oLabel, settingId, 'Yes')
                else:
                    config.set(self._oLabel, settingId, 'No')
        with open(iniFile, 'w', encoding='utf-8') as f:
            config.write(f)


def set_icon(widget, icon='logo', path=None, default=True):
    if path is None:
        path = os.path.dirname(sys.argv[0])
        if not path:
            path = '.'
        path = f'{path}/icons'
    try:
        pic = tk.PhotoImage(file=f'{path}/{icon}.png')
        widget.iconphoto(default, pic)
    except:
        return False

    return True

from tkinter import filedialog
from tkinter import messagebox
import webbrowser




def open_document(document):
    if PLATFORM == 'win':
        os.startfile(os.path.normpath(document))
        return

    if PLATFORM == 'ix':
        os.system('xdg-open "%s"' % os.path.normpath(document))
        return

    if PLATFORM == 'mac':
        os.system('open "%s"' % os.path.normpath(document))
from pathlib import Path


prefs = {}
HELP_URL = _('https://peter88213.github.io/yw_tlview/help/')
HOME_URL = 'https://github.com/peter88213/yw_tlview/'

HOME_DIR = str(Path.home()).replace('\\', '/')
INSTALL_DIR = f'{HOME_DIR}/.yw_tlview'


class TlviewerCommands:

    def about(self, event=None):
        messagebox.showinfo(
            message='yw Timeline viewer',
            detail=__doc__,
            title=_('About yw Timeline viewer'),
            )

    def bind_events(self):
        event_callbacks = {
            '<<about>>': self.about,
            '<<close_project>>': self.close_project,
            '<<close_view>>': self.on_quit,
            '<<create_project>>':self.create_project,
            '<<disable_undo>>': self.disable_undo_button,
            '<<enable_undo>>': self.enable_undo_button,
            '<<fit_window>>': self.tlv.fit_window,
            '<<go_to_first>>': self.tlv.go_to_first,
            '<<go_to_last>>': self.tlv.go_to_last,
            '<<increase_scale>>': self.tlv.increase_scale,
            '<<open_help>>': self.open_help,
            '<<open_homepage>>': self.open_homepage,
            '<<open_project>>': self.open_project,
            '<<open_project_file>>': self.open_project_file,
            '<<page_back>>': self.tlv.page_back,
            '<<page_forward>>': self.tlv.page_forward,
            '<<reduce_scale>>': self.tlv.reduce_scale,
            '<<refresh_view>>': self.tlv.refresh,
            '<<reload_project>>': self.reload_project,
            '<<reset_casc>>': self.tlv.reset_casc,
            '<<save_as>>': self.save_as,
            '<<save_project>>': self.save_project,
            '<<scroll_back>>': self.tlv.scroll_back,
            '<<scroll_forward>>': self.tlv.scroll_forward,
            '<<set_casc_relaxed>>': self.tlv.set_casc_relaxed,
            '<<set_casc_tight>>': self.tlv.set_casc_tight,
            '<<set_day_scale>>': self.tlv.set_day_scale,
            '<<set_hour_scale>>': self.tlv.set_hour_scale,
            '<<set_year_scale>>': self.tlv.set_year_scale,
            '<<undo>>': self.tlv.undo,
            KEYS.OPEN_PROJECT[0]: self.open_project,
            KEYS.RELOAD_PROJECT[0]: self.reload_project,
            KEYS.SAVE_AS[0]: self.save_as,
            KEYS.SAVE_PROJECT[0]: self.save_project,
        }
        for sequence, callback in event_callbacks.items():
            self.root.bind(sequence, callback)
        self.root.protocol("WM_DELETE_WINDOW", self.on_quit)

    def close_project(self, event=None):
        if self.mdl.isModified:
            answer = messagebox.askyesnocancel(
                title=_('Close'),
                message=_('Save changes?'),
                )
            if answer is None:
                return

            elif answer:
                self.save_project_file(self.prjFilePath)
        self.mdl.clear()
        self.prjFilePath = None
        self.show_path()
        self.disable_menu()

    def create_project(self, event=None):
        if self.mdl.isModified:
            answer = messagebox.askyesnocancel(
            title=_('New'),
            message=_('Save changes?'),
            )
            if answer is None:
                return

            elif answer:
                self.save_project_file(self.prjFilePath)
        if self.prjFilePath:
            initDir = os.path.dirname(self.prjFilePath)
        else:
            initDir = './'

        filePath = filedialog.asksaveasfilename(
            filetypes=self.filetypes,
            defaultextension=self.defaultFileClass.EXTENSION,
            initialdir=initDir
            )
        if not filePath:
            return

        self.mdl.clear()
        self.prjFilePath = filePath
        self.show_path()
        self.save_project()
        if messagebox.askyesno(
            title=_('Project created'),
            message=_('Open the file for data entry?'),
            ):
            self.open_project_file()

    def disable_undo_button(self, event=None):
        self._toolbar.undoButton.config(state='disabled')

    def enable_undo_button(self, event=None):
        self._toolbar.undoButton.config(state='normal')

    def open_help(self, event=None):
        webbrowser.open(HELP_URL)

    def open_homepage(self, event=None):
        webbrowser.open(HOME_URL)

    def open_project(self, event=None):
        if self.mdl.isModified:
            answer = messagebox.askyesnocancel(
            title=_('Open'),
            message=_('Save changes?'),
            )
            if answer is None:
                return

            elif answer:
                self.save_project_file(self.prjFilePath)
        if self.prjFilePath:
            initDir = os.path.dirname(self.prjFilePath)
        else:
            initDir = './'

        filePath = filedialog.askopenfilename(
            filetypes=self.filetypes,
            defaultextension=self.defaultFileClass.EXTENSION,
            initialdir=initDir
            )
        if filePath:
            self.read_data(filePath)

    def open_project_file(self, event=None):
        if self.mdl.isModified:
            answer = messagebox.askyesnocancel(
            title=_('Open project file'),
            message=_('Save changes?'),
            )
            if answer is None:
                return

            elif answer:
                self.save_project_file(self.prjFilePath)
        if self.prjFilePath:
            open_document(self.prjFilePath)

    def open_section(self, scId):
        print(scId)

    def reload_project(self, event=None):
        if self.prjFilePath is not None:
            self.read_data(self.prjFilePath)

    def save_as(self, event=None):
        if self.prjFilePath is None:
            return

        if self.prjFilePath:
            initDir = os.path.dirname(self.prjFilePath)
        else:
            initDir = './'

        filePath = filedialog.asksaveasfilename(
            filetypes=self.filetypes,
            defaultextension=self.defaultFileClass.EXTENSION,
            initialdir=initDir
            )
        if filePath:
            self.prjFilePath = filePath
            self.save_project()
            self.refresh()

    def save_project(self, event=None):
        if self.prjFilePath:
            try:
                self.mdl.write_data(self.prjFilePath)
            except Exception as ex:
                messagebox.showerror(
                    self.root.title(),
                    message=_('Cannot write file'),
                    detail=str(ex),
                    )

from tkinter import messagebox



class TlviewerMenu(tk.Menu):

    def __init__(self, master, cnf={}, **kw):
        super().__init__(master=master, cnf=cnf, **kw)

        self.fileMenu = tk.Menu(self, tearoff=0)
        self.add_cascade(label=_('File'), menu=self.fileMenu)
        self.fileMenu.add_command(label=_('Open...'), accelerator=KEYS.OPEN_PROJECT[1], command=self._event('<<open_project>>'))
        self.fileMenu.add_command(label=_('Reload'), accelerator=KEYS.RELOAD_PROJECT[1], command=self._event('<<reload_project>>'))
        self.fileMenu.add_command(label=_('Close'), command=self._event('<<close_project>>'))
        if PLATFORM == 'win':
            label = _('Exit')
        else:
            label = _('Quit')
        self.fileMenu.add_command(label=label, accelerator=KEYS.QUIT_PROGRAM[1], command=self._event('<<close_view>>'))

        self.goMenu = tk.Menu(self, tearoff=0)
        self.add_cascade(label=_('Go to'), menu=self.goMenu)
        self.goMenu.add_command(label=_('First event'), command=self._event('<<go_to_first>>'))
        self.goMenu.add_command(label=_('Last event'), command=self._event('<<go_to_last>>'))

        self.scaleMenu = tk.Menu(self, tearoff=0)
        self.add_cascade(label=_('Scale'), menu=self.scaleMenu)
        self.scaleMenu.add_command(label=_('Hours'), command=self._event('<<set_hour_scale>>'))
        self.scaleMenu.add_command(label=_('Days'), command=self._event('<<set_day_scale>>'))
        self.scaleMenu.add_command(label=_('Years'), command=self._event('<<set_year_scale>>'))
        self.scaleMenu.add_command(label=_('Fit to window'), command=self._event('<<fit_window>>'))

        self.cascadeMenu = tk.Menu(self, tearoff=0)
        self.add_cascade(label=_('Cascading'), menu=self.cascadeMenu)
        self.cascadeMenu.add_command(label=_('Tight'), command=self._event('<<set_casc_tight>>'))
        self.cascadeMenu.add_command(label=_('Relaxed'), command=self._event('<<set_casc_relaxed>>'))
        self.cascadeMenu.add_command(label=_('Standard'), command=self._event('<<reset_casc>>'))

        self.toolsMenu = tk.Menu(self, tearoff=0)
        self.add_cascade(label=_('Tools'), menu=self.toolsMenu)

        self.optionsMenu = tk.Menu(self, tearoff=0)
        self.toolsMenu.add_cascade(label=_('Options'), menu=self.optionsMenu)

        self._substituteMissingTime = tk.BooleanVar(value=prefs['substitute_missing_time'])
        self.optionsMenu.add_checkbutton(
            label=_('Use 00:00 for missing times'),
            variable=self._substituteMissingTime,
            command=self._change_substitution_mode,
            )
        self._largeIcons = tk.BooleanVar(value=prefs['large_icons'])
        self.optionsMenu.add_checkbutton(
            label=_('Large toolbar icons'),
            variable=self._largeIcons,
            command=self._change_icon_size,
            )

        self.helpMenu = tk.Menu(self, tearoff=0)
        self.add_cascade(label=_('Help'), menu=self.helpMenu)
        self.helpMenu.add_command(label=_('Online help'), command=self._event('<<open_help>>'))
        self.helpMenu.add_command(label=_('About yw Timeline viewer'), command=self._event('<<about>>'))
        self.helpMenu.add_command(label=f"yw Timeline viewer {_('Home page')}", command=self._event('<<open_homepage>>'))

        self._fileMenuNormalOpen = [
            _('Close'),
            _('Reload'),
        ]
        self._mainMenuNormalOpen = [
            _('Go to'),
            _('Scale'),
            _('Cascading'),
        ]
        self.disable_menu()

    def _event(self, sequence):

        def callback(*_):
            root = self.master.winfo_toplevel()
            root.event_generate(sequence)

        return callback

    def disable_menu(self):
        for entry in self._fileMenuNormalOpen:
            self.fileMenu.entryconfig(entry, state='disabled')
        for entry in self._mainMenuNormalOpen:
            self.entryconfig(entry, state='disabled')

    def enable_menu(self):
        for entry in self._fileMenuNormalOpen:
            self.fileMenu.entryconfig(entry, state='normal')
        for entry in self._mainMenuNormalOpen:
            self.entryconfig(entry, state='normal')

    def _change_icon_size(self):
        prefs['large_icons'] = self._largeIcons.get()
        messagebox.showinfo(
            message=_('Icon size changed'),
            detail=f"{_('The change takes effect after next startup')}.",
            title=_('Options'),
            )

    def _change_substitution_mode(self):
        prefs['substitute_missing_time'] = self._substituteMissingTime.get()
        root = self.master.winfo_toplevel()
        root.event_generate('<<refresh_view>>')


class TlviewerPathBar(tk.Label):

    COLOR_MODIFIED_BG = 'goldenrod1'
    COLOR_MODIFIED_FG = 'maroon'
    COLOR_NORMAL_BG = 'light gray'
    COLOR_NORMAL_FG = 'black'

    def __init__(self, master, model, **kw):
        tk.Label.__init__(self, master, **kw)
        self._mdl = model

    def refresh(self):
        if self._mdl.isModified:
            self.set_modified()
        else:
            self.set_normal()

    def set_modified(self):
        self.config(bg=self.COLOR_MODIFIED_BG)
        self.config(fg=self.COLOR_MODIFIED_FG)

    def set_normal(self):
        self.config(bg=self.COLOR_NORMAL_BG)
        self.config(fg=self.COLOR_NORMAL_FG)
from tkinter import ttk



class TooltipBase:

    def __init__(self, anchor_widget):
        self.anchor_widget = anchor_widget
        self.tipwindow = None

    def __del__(self):
        self.hidetip()

    def showtip(self):
        if self.tipwindow:
            return
        self.tipwindow = tw = tk.Toplevel(self.anchor_widget)
        tw.wm_overrideredirect(1)
        try:
            tw.tk.call("::tk::unsupported::MacWindowStyle", "style", tw._w,
                       "help", "noActivates")
        except tk.TclError:
            pass

        self.position_window()
        self.showcontents()
        self.tipwindow.update_idletasks()  # Needed on MacOS -- see #34275.
        self.tipwindow.lift()  # work around bug in Tk 8.5.18+ (issue #24570)

    def position_window(self):
        x, y = self.get_position()
        root_x = self.anchor_widget.winfo_rootx() + x
        root_y = self.anchor_widget.winfo_rooty() + y
        self.tipwindow.wm_geometry("+%d+%d" % (root_x, root_y))

    def get_position(self):
        return 20, self.anchor_widget.winfo_height() + 1

    def showcontents(self):
        raise NotImplementedError

    def hidetip(self):
        tw = self.tipwindow
        self.tipwindow = None
        if tw:
            try:
                tw.destroy()
            except tk.TclError:  # pragma: no cover
                pass


class OnHoverTooltipBase(TooltipBase):

    def __init__(self, anchor_widget, hover_delay=1000):
        super().__init__(anchor_widget)
        self.hover_delay = hover_delay

        self._after_id = None
        self._id1 = self.anchor_widget.bind("<Enter>", self._show_event)
        self._id2 = self.anchor_widget.bind("<Leave>", self._hide_event)
        self._id3 = self.anchor_widget.bind("<Button>", self._hide_event)

    def __del__(self):
        try:
            self.anchor_widget.unbind("<Enter>", self._id1)
            self.anchor_widget.unbind("<Leave>", self._id2)  # pragma: no cover
            self.anchor_widget.unbind("<Button>", self._id3)  # pragma: no cover
        except tk.TclError:
            pass
        super().__del__()

    def _show_event(self, event=None):
        if self.hover_delay:
            self.schedule()
        else:
            self.showtip()

    def _hide_event(self, event=None):
        self.hidetip()

    def schedule(self):
        self.unschedule()
        self._after_id = self.anchor_widget.after(self.hover_delay,
                                                  self.showtip)

    def unschedule(self):
        after_id = self._after_id
        self._after_id = None
        if after_id:
            self.anchor_widget.after_cancel(after_id)

    def hidetip(self):
        try:
            self.unschedule()
        except tk.TclError:  # pragma: no cover
            pass
        super().hidetip()


class Hovertip(OnHoverTooltipBase):
    "A tooltip that pops up when a mouse hovers over an anchor widget."

    def __init__(self, anchor_widget, text, hover_delay=1000):
        super().__init__(anchor_widget, hover_delay=hover_delay)
        self.text = text

    def showcontents(self):
        label = tk.Label(self.tipwindow, text=self.text, justify='left',
                      background="#ffffe0", relief='solid', borderwidth=1)
        label.pack()



class TlviewerToolbar(ttk.Frame):

    def __init__(self, master):
        ttk.Frame.__init__(self, master)

        if prefs['large_icons']:
            size = 24
        else:
            size = 16
        iconPath = f'{INSTALL_DIR}/icons/{size}'
        self._toolbarIcons = {}
        icons = [
            'rewindLeft',
            'arrowLeft',
            'goToFirst',
            'goToLast',
            'arrowRight',
            'rewindRight',
            'fitToWindow',
            'arrowUp',
            'arrowDown',
            'undo',
            ]
        for icon in icons:
            try:
                self._toolbarIcons[icon] = tk.PhotoImage(file=f'{iconPath}/{icon}.png')
            except:
                self._toolbarIcons[icon] = None

        self.buttons = list()

        rewindLeftButton = ttk.Button(
            self,
            text=_('Page back'),
            image=self._toolbarIcons['rewindLeft'],
            command=self._event('<<page_back>>')
            )
        rewindLeftButton.pack(side='left')
        rewindLeftButton.image = self._toolbarIcons['rewindLeft']
        self.buttons.append(rewindLeftButton)

        arrowLeftButton = ttk.Button(
            self,
            text=_('Scroll back'),
            image=self._toolbarIcons['arrowLeft'],
            command=self._event('<<scroll_back>>')
            )
        arrowLeftButton.pack(side='left')
        arrowLeftButton.image = self._toolbarIcons['arrowLeft']
        self.buttons.append(arrowLeftButton)

        goToFirstButton = ttk.Button(
            self,
            text=_('First event'),
            image=self._toolbarIcons['goToFirst'],
            command=self._event('<<go_to_first>>')
            )
        goToFirstButton.pack(side='left')
        goToFirstButton.image = self._toolbarIcons['goToFirst']
        self.buttons.append(goToFirstButton)

        goToLastButton = ttk.Button(
            self,
            text=_('Last event'),
            image=self._toolbarIcons['goToLast'],
            command=self._event('<<go_to_last>>')
            )
        goToLastButton.pack(side='left')
        goToLastButton.image = self._toolbarIcons['goToLast']
        self.buttons.append(goToLastButton)

        arrowRightButton = ttk.Button(
            self,
            text=_('Scroll forward'),
            image=self._toolbarIcons['arrowRight'],
            command=self._event('<<scroll_forward>>')
            )
        arrowRightButton.pack(side='left')
        arrowRightButton.image = self._toolbarIcons['arrowRight']
        self.buttons.append(arrowRightButton)

        rewindRightButton = ttk.Button(
            self,
            text=_('Page forward'),
            image=self._toolbarIcons['rewindRight'],
            command=self._event('<<page_forward>>')
            )
        rewindRightButton.pack(side='left')
        rewindRightButton.image = self._toolbarIcons['rewindRight']
        self.buttons.append(rewindRightButton)

        tk.Frame(self, bg='light gray', width=1).pack(side='left', fill='y', padx=6)

        arrowDownButton = ttk.Button(
            self,
            text=_('Reduce scale'),
            image=self._toolbarIcons['arrowDown'],
            command=self._event('<<reduce_scale>>')
            )
        arrowDownButton.pack(side='left')
        arrowDownButton.image = self._toolbarIcons['arrowDown']
        self.buttons.append(arrowDownButton)

        fitToWindowButton = ttk.Button(
            self,
            text=_('Fit to window'),
            image=self._toolbarIcons['fitToWindow'],
            command=self._event('<<fit_window>>')
            )
        fitToWindowButton.pack(side='left')
        fitToWindowButton.image = self._toolbarIcons['fitToWindow']
        self.buttons.append(fitToWindowButton)

        arrowUpButton = ttk.Button(
            self,
            text=_('Increase scale'),
            image=self._toolbarIcons['arrowUp'],
            command=self._event('<<increase_scale>>')
            )
        arrowUpButton.pack(side='left')
        arrowUpButton.image = self._toolbarIcons['arrowUp']
        self.buttons.append(arrowUpButton)


        self.undoButton = ttk.Button(
            self,
            text=_('Undo'),
            image=self._toolbarIcons['undo'],
            command=self._event('<<undo>>'),
            state='disabled',
            )
        self.undoButton.image = self._toolbarIcons['undo']

        if not prefs['enable_hovertips']:
            return

        Hovertip(rewindLeftButton, rewindLeftButton['text'])
        Hovertip(arrowLeftButton, arrowLeftButton['text'])
        Hovertip(goToFirstButton, goToFirstButton['text'])
        Hovertip(goToLastButton, goToLastButton['text'])
        Hovertip(arrowRightButton, arrowRightButton['text'])
        Hovertip(rewindRightButton, rewindRightButton['text'])
        Hovertip(arrowDownButton, arrowDownButton['text'])
        Hovertip(fitToWindowButton, fitToWindowButton['text'])
        Hovertip(arrowUpButton, arrowUpButton['text'])
        Hovertip(self.undoButton, self.undoButton['text'])

    def _event(self, sequence):

        def callback(*_):
            root = self.master.winfo_toplevel()
            root.event_generate(sequence)

        return callback

    def disable_menu(self):
        for button in self.buttons:
            button.config(state='disabled')
        self.undoButton.config(state='disabled')

    def enable_menu(self):
        for button in self.buttons:
            button.config(state='normal')

SETTINGS = dict(
    last_open='',
    window_geometry='1200x800',
)
OPTIONS = dict(
    enable_hovertips=True,
    substitute_missing_time=False,
    large_icons=False,
    localize_date=True,
    )


class TimelineViewer(TlviewerCommands):

    def __init__(self):

        self.defaultFileClass = Yw7File
        self.mdl = TlvDataModel(self.defaultFileClass)
        self.filetypes = [
            (self.defaultFileClass.DESCRIPTION, self.defaultFileClass.EXTENSION),
        ]
        self.prjFilePath = None

        if prefs['localize_date']:
            locale.setlocale(locale.LC_TIME, "")

        self.root = tk.Tk()
        self.root.title('yw Timeline viewer')
        self.root.geometry(prefs['window_geometry'])
        set_icon(self.root, icon='tlv')

        self._mainMenu = TlviewerMenu(self.root)
        self.root.config(menu=self._mainMenu)

        mainWindow = ttk.Frame(self.root)
        mainWindow.pack(fill='both', expand=True)
        self._pathBar = TlviewerPathBar(mainWindow, self.mdl, text='', anchor='w', padx=5, pady=3)
        self._pathBar.pack(side='bottom', expand=False, fill='x')
        self.mdl.add_observer(self._pathBar)
        self._toolbar = TlviewerToolbar(mainWindow)
        self._toolbar.pack(side='bottom', fill='x', padx=5, pady=2)

        self.tlv = TlvController(
            self.mdl,
            mainWindow,
            prefs,
            onDoubleClick=self.open_section,
            )
        self.mdl.add_observer(self.tlv)

        self.bind_events()

        self.tlv.lock()

    def disable_menu(self):
        """Disable menu entries when no project is open.
        
        To be extended by subclasses.
        """
        self._mainMenu.disable_menu()
        self._toolbar.disable_menu()

    def enable_menu(self):
        """Enable menu entries when a project is open.
        
        To be extended by subclasses.
        """
        self._mainMenu.enable_menu()
        self._toolbar.enable_menu()

    def on_quit(self, event=None):
        try:
            if self.mdl.isModified:
                answer = messagebox.askyesnocancel(
                    title=_('Quit'),
                    message=_('Save changes?'),
                    )
                if answer is None:
                    return

                elif answer:
                    self.save_project_file(self.prjFilePath)
            prefs['window_geometry'] = self.root.winfo_geometry()
            self.tlv.on_quit()
        except Exception as ex:
            messagebox.showerror(
                message=_('Unhandled exception on exit'),
                detail=str(ex),
                title=_('Error'),
                )
        finally:
            self.root.quit()

    def read_data(self, filePath):
        self.mdl.clear()
        try:
            self.mdl.read_data(filePath)
        except Exception as ex:
            self.mdl.clear()
            self.prjFilePath = None
            self.disable_menu()
            messagebox.showerror(
                self.root.title(),
                message=_('Cannot read file'),
                detail=str(ex),
                )
        else:
            self.prjFilePath = filePath
        finally:
            self.refresh()
        prefs['last_open'] = filePath

    def refresh(self, event=None):
        self.tlv.refresh()
        self.tlv.fit_window()
        self.enable_menu()
        self.show_path()

    def show_path(self):
        if self.prjFilePath is None:
            filePath = ''
        else:
            filePath = os.path.normpath(self.prjFilePath)
        self._pathBar.config(text=filePath)

    def start(self):
        self.root.mainloop()


def main():
    os.makedirs(INSTALL_DIR, exist_ok=True)
    configDir = f'{INSTALL_DIR}/config'
    os.makedirs(configDir, exist_ok=True)

    iniFile = f'{configDir}/tlviewer.ini'
    configuration = Configuration(SETTINGS, OPTIONS)
    try:
        configuration.read(iniFile)
    except:
        pass
    prefs.update(configuration.settings)
    prefs.update(configuration.options)

    app = TimelineViewer()

    try:
        filePath = sys.argv[1]
    except IndexError:
        filePath = ''
    if not filePath or not os.path.isfile(filePath):
        filePath = prefs['last_open']
    if filePath and os.path.isfile(filePath):
        app.read_data(filePath)


    app.start()

    for keyword in prefs:
        if keyword in configuration.options:
            configuration.options[keyword] = prefs[keyword]
        elif keyword in configuration.settings:
            configuration.settings[keyword] = prefs[keyword]
    configuration.write(iniFile)


if __name__ == '__main__':
    main()

